package in.co.canteen.mg.Model;

import in.co.canteen.mg.Bean.ContactUsBean;
import in.co.canteen.mg.Utility.DBUtility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ContactUsModel {
    public boolean saveContact(ContactUsBean bean) {
        String sql = "INSERT INTO contact_us (name, email, subject, message) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtility.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, bean.getName());
            ps.setString(2, bean.getEmail());
            ps.setString(3, bean.getSubject());
            ps.setString(4, bean.getMessage());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<ContactUsBean> getAllContacts() {
        String sql = "SELECT * FROM contact_us ORDER BY created_at DESC";
        List<ContactUsBean> contacts = new ArrayList<>();
        try (Connection conn = DBUtility.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                ContactUsBean bean = new ContactUsBean();
                bean.setId(rs.getInt("id"));
                bean.setName(rs.getString("name"));
                bean.setEmail(rs.getString("email"));
                bean.setSubject(rs.getString("subject"));
                bean.setMessage(rs.getString("message"));
                bean.setCreatedAt(rs.getString("created_at"));
                contacts.add(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return contacts;
    }
}
