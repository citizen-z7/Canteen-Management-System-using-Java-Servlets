package in.co.canteen.mg.Model;

import in.co.canteen.mg.Bean.TableBookingBean;
import in.co.canteen.mg.Utility.DBUtility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TableBookingModel {
	public boolean saveBooking(TableBookingBean booking) {
	    String sql = "INSERT INTO table_bookings (user_name, user_email, booking_date, booking_time, number_of_people) VALUES (?, ?, ?, ?, ?)";
	    try (Connection conn = DBUtility.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        // Log Booking Details
	        System.out.println("Executing saveBooking with:");
	        System.out.println("User Name: " + booking.getUserName());
	        System.out.println("User Email: " + booking.getUserEmail());
	        System.out.println("Booking Date: " + booking.getBookingDate());
	        System.out.println("Booking Time: " + booking.getBookingTime());
	        System.out.println("Number of People: " + booking.getNumberOfPeople());

	        // Set PreparedStatement Parameters
	        ps.setString(1, booking.getUserName());
	        ps.setString(2, booking.getUserEmail());
	        ps.setString(3, booking.getBookingDate());
	        ps.setString(4, booking.getBookingTime());
	        ps.setInt(5, booking.getNumberOfPeople());

	        int rowsInserted = ps.executeUpdate();

	        // Log the Result
	        System.out.println("Rows Inserted: " + rowsInserted);
	        return rowsInserted > 0;
	    } catch (SQLException e) {
	        System.err.println("SQL Error in saveBooking:");
	        System.err.println("Error Code: " + e.getErrorCode());
	        System.err.println("SQL State: " + e.getSQLState());
	        System.err.println("Message: " + e.getMessage());
	        e.printStackTrace();
	        return false;
	    }
	}

}
