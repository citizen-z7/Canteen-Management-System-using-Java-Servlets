package in.co.canteen.mg.Controller;

import in.co.canteen.mg.Bean.OfferBean;
import in.co.canteen.mg.Model.OfferModel;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "OffersCtl", urlPatterns = "/OffersCtl")
public class OffersCtl extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        OfferModel model = new OfferModel();
        try {
            List<OfferBean> offers = model.getAllOffers();
            System.out.println("Offers Retrieved: " + offers); // Debug log to ensure data is fetched
            request.setAttribute("offers", offers); // Set the offers list in the request
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error loading offers: " + e.getMessage());
        }
        RequestDispatcher rd = request.getRequestDispatcher(CMSView.OFFERS_VIEW);
        rd.forward(request, response);
    }
}
