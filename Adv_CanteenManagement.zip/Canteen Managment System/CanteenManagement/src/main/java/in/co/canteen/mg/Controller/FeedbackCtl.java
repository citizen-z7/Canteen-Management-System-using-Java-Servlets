package in.co.canteen.mg.Controller;

import in.co.canteen.mg.Bean.ProductFeedbackBean;
import in.co.canteen.mg.Utility.ServletUtility;
import in.co.canteen.mg.Model.FeedbackModel;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "FeedbackCtl",urlPatterns = "/FeedbackCtl")
public class FeedbackCtl extends HttpServlet {

	// Inside FeedbackCtl Servlet
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String userName = request.getParameter("userName");
	    String userEmail = request.getParameter("userEmail");
	    String feedbackMessage = request.getParameter("feedbackMessage");
	    int rating = Integer.parseInt(request.getParameter("rating"));

	    ProductFeedbackBean feedbackBean = new ProductFeedbackBean();
	    feedbackBean.setUserName(userName);
	    feedbackBean.setUserEmail(userEmail);
	    feedbackBean.setFeedbackMessage(feedbackMessage);
	    feedbackBean.setRating(rating);

	    FeedbackModel feedbackModel = new FeedbackModel();
	    boolean isInserted = feedbackModel.saveFeedback(feedbackBean);

	    if (isInserted) {
	        ServletUtility.setSuccessMessage("Feedback submitted successfully!", request);
	    } else {
	        ServletUtility.setErrorMessage("Error submitting feedback. Please try again.", request);
	    }

	    // Forward to Feedback.jsp
	    ServletUtility.forward("/jsp/Feedback.jsp", request, response);
	    response.sendRedirect(request.getContextPath() + "/jsp/Feedback.jsp");

	}

}

