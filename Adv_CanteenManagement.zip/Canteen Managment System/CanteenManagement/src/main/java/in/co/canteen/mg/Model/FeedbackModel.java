package in.co.canteen.mg.Model;

import in.co.canteen.mg.Bean.ProductFeedbackBean;
import in.co.canteen.mg.Utility.DBUtility;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class FeedbackModel {

	public boolean saveFeedback(ProductFeedbackBean feedbackBean) {
	    boolean result = false;
	    
	    // Use try-with-resources to ensure the connection is closed automatically
	    try (Connection conn = DBUtility.getConnection()) {
	        
	        // SQL query to insert the feedback data into the database
	        String sql = "INSERT INTO feedback (userName, userEmail, feedbackMessage, rating) VALUES (?, ?, ?, ?)";
	        
	        // Prepare the statement with the given query
	        try (PreparedStatement ps = conn.prepareStatement(sql)) {
	            ps.setString(1, feedbackBean.getUserName());
	            ps.setString(2, feedbackBean.getUserEmail());
	            ps.setString(3, feedbackBean.getFeedbackMessage());
	            ps.setInt(4, feedbackBean.getRating());
	            
	            // Execute the query and check if any rows were affected
	            int rowsAffected = ps.executeUpdate();
	            
	            // If rows are affected, the insert was successful
	            if (rowsAffected > 0) {
	                result = true;
	            }
	        }
	        
	    } catch (Exception e) {
	        // Log or print the exception to understand what went wrong
	        e.printStackTrace(); // For now, use this for simplicity. Use a logger in production.
	    }
	    
	    return result;
	}

}
