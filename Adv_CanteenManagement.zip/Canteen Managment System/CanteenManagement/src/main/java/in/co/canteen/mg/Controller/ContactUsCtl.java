package in.co.canteen.mg.Controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ContactUsCtl", urlPatterns = "/contactUs")
public class ContactUsCtl extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String subject = request.getParameter("subject");
        String message = request.getParameter("message");

        try {
            if (name != null && email != null && subject != null && message != null) {
                // Here, save the data to the database or process it as required.
                request.setAttribute("successMessage", "Thank you for contacting us. We will get back to you soon.");
                System.out.println("Success Message: " + request.getAttribute("successMessage"));
                

            } else {
                request.setAttribute("errorMessage", "All fields are required.");
                System.out.println("Error Message: " + request.getAttribute("errorMessage"));
            }
        } catch (Exception e) {
            request.setAttribute("errorMessage", "An error occurred while processing your request.");
            System.out.println("Error Message: " + request.getAttribute("errorMessage"));
        }

        RequestDispatcher rd = request.getRequestDispatcher("/jsp/ContactUs.jsp");
        rd.forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher("/jsp/ContactUs.jsp");
        rd.forward(request, response);
    }
}
