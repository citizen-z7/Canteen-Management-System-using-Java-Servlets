package in.co.canteen.mg.Utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestDBConnection {

	public static void main(String[] args) {
	    try (Connection conn = DBUtility.getConnection()) {
	        System.out.println("Connection successful!");
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

}
