package in.co.canteen.mg.Model;

import in.co.canteen.mg.Bean.OfferBean;
import in.co.canteen.mg.Utility.DBUtility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OfferModel {
	public List<OfferBean> getAllOffers() {
	    List<OfferBean> offers = new ArrayList<>();
	    String sql = "SELECT * FROM offers WHERE active = 1";
	    try (Connection conn = DBUtility.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {
	        while (rs.next()) {
	            OfferBean offer = new OfferBean();
	            offer.setId(rs.getInt("id"));
	            offer.setTitle(rs.getString("title"));
	            offer.setDescription(rs.getString("description"));
	            offer.setDiscountPercentage(rs.getDouble("discount_percentage"));
	            offer.setStartDate(rs.getDate("start_date").toString());
	            offer.setEndDate(rs.getDate("end_date").toString());
	            offer.setActive(rs.getBoolean("active"));
	            System.out.println("Offer Fetched: " + offer); // Debug log
	            offers.add(offer);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    System.out.println("Total offers retrieved: " + offers.size());
	    return offers;
	}


}
