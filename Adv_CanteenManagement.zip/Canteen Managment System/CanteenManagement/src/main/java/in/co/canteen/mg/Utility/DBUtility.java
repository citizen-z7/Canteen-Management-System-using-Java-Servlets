package in.co.canteen.mg.Utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtility {

    // Database credentials
	private static final String DB_URL = "jdbc:mysql://localhost:3306/canteenmg?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    // Method to get a connection to the database
    public static Connection getConnection() throws SQLException {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL JDBC Driver loaded successfully.");

            // Establish the connection
            System.out.println("Connecting to database: " + DB_URL);
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
            System.out.println("Database connection established.");
            return conn;
        } catch (ClassNotFoundException e) {
            throw new SQLException("JDBC Driver not found.", e);
        } catch (SQLException e) {
            System.err.println("Failed to establish a database connection:");
            System.err.println("Error Code: " + e.getErrorCode());
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("Message: " + e.getMessage());
            throw e;
        }
    }

}
