package in.co.canteen.mg.Controller;

import in.co.canteen.mg.Bean.TableBookingBean;
import in.co.canteen.mg.Model.TableBookingModel;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;


@WebServlet(name = "TableBookingCtl", urlPatterns = "/TableBookingCtl")
public class TableBookingCtl extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userName = request.getParameter("userName");
        String userEmail = request.getParameter("userEmail");
        String bookingDate = request.getParameter("bookingDate");
        String bookingTime = request.getParameter("bookingTime");
        String numberOfPeopleStr = request.getParameter("numberOfPeople");

        // Validation
        if (userName == null || userName.isEmpty() || userEmail == null || userEmail.isEmpty() ||
            bookingDate == null || bookingDate.isEmpty() || bookingTime == null || bookingTime.isEmpty() ||
            numberOfPeopleStr == null || numberOfPeopleStr.isEmpty()) {
            request.setAttribute("errorMessage", "All fields are required!");
            RequestDispatcher rd = request.getRequestDispatcher("/jsp/TableBooking.jsp");
            rd.forward(request, response);
            return;
        }

        int numberOfPeople = Integer.parseInt(numberOfPeopleStr);

        // Save booking
        TableBookingBean booking = new TableBookingBean();
        booking.setUserName(userName);
        booking.setUserEmail(userEmail);
        booking.setBookingDate(bookingDate);
        booking.setBookingTime(bookingTime);
        booking.setNumberOfPeople(numberOfPeople);

        TableBookingModel model = new TableBookingModel();
        boolean isBooked = model.saveBooking(booking);

        if (isBooked) {
            request.setAttribute("successMessage", "Table booked successfully!");
        } else {
            request.setAttribute("errorMessage", "Error booking table. Please try again.");
        }

        RequestDispatcher rd = request.getRequestDispatcher("/jsp/TableBooking.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher("/jsp/TableBooking.jsp");
        rd.forward(request, response);
    }
}

