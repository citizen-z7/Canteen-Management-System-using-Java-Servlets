package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTest;

public class orderFromMenu extends BaseTest {
	
	@Test (dataProvider="testdata",priority=1)
	public void logIn(String username, String Password) throws InterruptedException 
	{
		
	driver.findElement(By.xpath(loc.getProperty("login_page"))).click();
	Thread.sleep(1000);
	driver.findElement(By.xpath(loc.getProperty("login_username"))).sendKeys(username);
	Thread.sleep(1000);
	driver.findElement(By.xpath(loc.getProperty("login_password"))).sendKeys(Password);
	Thread.sleep(1000);
	driver.findElement(By.xpath(loc.getProperty("login_button"))).click();
	Thread.sleep(1000);
	
	
	}
	
	@DataProvider(name="testdata")
	public Object[][] tData()
	{
		return new Object[][] 
			{
				
				{"ro@gmail.com","123"}				
				 	
			};		
					
	}
	
	@Test(priority=2)
	public void verifyLogin() throws InterruptedException 
	{
		driver.findElement(By.partialLinkText(loc.getProperty("user_welcome"))).isDisplayed();
		Thread.sleep(2000);
		System.out.println("User Logged In");
	}
	
	@Test(priority=3)
	public void productSelect() throws InterruptedException
	{
		
		driver.findElement(By.xpath(loc.getProperty("product_list"))).click();
		
		//driver.switchTo().frame(driver.findElement(By.xpath(loc.getProperty("form_xpath"))));	
		JavascriptExecutor js = (JavascriptExecutor) driver;			
		js.executeScript("scroll(0, 450)");
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath(loc.getProperty("product_add_to_cart"))).click();
		js.executeScript("scroll(450, 0)");
		String str = driver.findElement(By.xpath(loc.getProperty("product_added_msg"))).getText();
		System.out.println(str);
		
		//driver.findElement(By.xpath("")).click();
		driver.findElement(By.xpath(loc.getProperty("cart"))).click();
		Thread.sleep(2000);
		
	}
	
	
	@Test(priority=4)
	public void payment() throws InterruptedException
	{
		
		
		driver.findElement(By.xpath(loc.getProperty("account_number"))).sendKeys(loc.getProperty("acc_value"));
		driver.findElement(By.xpath(loc.getProperty("bank_name"))).sendKeys(loc.getProperty("bank_value"));
		driver.findElement(By.xpath(loc.getProperty("card_number"))).sendKeys(loc.getProperty("card_value"));
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;			
		js.executeScript("scroll(0, 850)");
		Thread.sleep(2000);
		driver.findElement(By.xpath(loc.getProperty("payment_now"))).click();
		String msg = driver.findElement(By.xpath(loc.getProperty("payment_confirmation"))).getText();
		System.out.println(msg);
		driver.findElement(By.xpath(loc.getProperty("logout"))).click();
	}
	
}
